import utils as ut
import numpy as np
from pylab import plt

from FlowCytometryTools import ThresholdGate
from sklearn.manifold import MDS


def main():
    np.seterr(divide = 'ignore') 
    # the current directory (this should be replace by link to the fcs files from the cloud storage )
    directory = r'fcs_files'
    datasets = ut.loading_fcs_from_directory(directory)
    # After reading the files we transforms the data and keep only the dataframe from the FCS file 
    g=0
    for data in datasets:
        datasets[g] = ut.transformed_data(data)
        # ut.plot_fl1_fl3(datasets[g])
        g=g+1
        
    
    ut.plot_fl1_fl3(datasets[0])
    gate_1 = ThresholdGate(0, ['FL1-A'], region='above')
    gate_2 = ThresholdGate(6000, ['FL1-A'], region='below')
    gate_3 = ThresholdGate(2500, ['FL3-A'], region='above')
    gate_4 = ThresholdGate(4500, ['FL3-A'], region='below')
    composite_gate = (gate_1 & gate_2) & (gate_3 & gate_4)
    gated_sample = datasets[0].gate(composite_gate)
    
    nmds = MDS(n_components=4, metric=False, max_iter=3000, eps=1e-12, dissimilarity="euclidean", n_jobs=1,  n_init=1)
    npos = nmds.fit_transform(gated_sample.data)
    print(npos)
    print(nmds.stress_)
    plt.scatter(npos[:, 0], npos[:, 1], color='darkorange', s=1, lw=0, label='NMDS')
    plt.legend(scatterpoints=1, loc='best', shadow=False)
    plt.show()

    
main()